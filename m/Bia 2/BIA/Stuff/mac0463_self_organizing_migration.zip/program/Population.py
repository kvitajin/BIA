import random
import numpy as np
from Individual import Individual
from operator import attrgetter

class Population:

    # Privátní promměná, která nabývá hodnoty true, pokud již jedinci byli ohodnoceni (kvůli výběru nejlepšího jedince)
    __individualsWereCalculated = False
    # Privátní hodnota indexu pro následujícího jedince
    __lastCreatedIndex = 0

    def __init__(self, interval, dimension):
        self.interval = interval
        self.dimension = dimension
        self.individuals = []

    # Navýšení indexu pro nového jedince
    def __IncrementLastCreatedIndex(self):
        self.__lastCreatedIndex += 1

    # Generuje náhodné hodnoty pro vyhledávání skrze hodnoty z intervalu a dimenze
    def GenerateIndividual(self):
        array = []

        for _ in range(self.dimension):  
            array.append(random.uniform(self.interval.lowerBound, self.interval.upperBound))
            
        individual = Individual(array, self.__lastCreatedIndex)
        self.__IncrementLastCreatedIndex()
        
        return individual

    # Vytvoření populace jedinců
    def GenerateIndividuals(self, number):
        if self.individuals:
            return

        for _ in range(number):
            self.individuals.append(self.GenerateIndividual())

    # Výpočet hodnot na funkci pro všechny jedince
    def CalculateIndividuals(self, func):
        self.__individualsWereCalculated = True

        for individual in self.individuals:
            individual.CalculateF(func)
            individual.GenerateNewPosition()

    # Výpočet hodnotu funkce na konkrétním jedinci
    def CalculateIndividual(self, func, individual):
        individual.CalculateF(func)

    # Funkce vrací nejlepšího jedince, pokud nebyli ještě jedinci ohodnoceni, vrátí se hodnota None
    def GetBestIndividual(self):
        if not self.__individualsWereCalculated:
            return None
        return min(self.individuals, key = attrgetter("f"))