from Point import Point
from Graph import Graph
from Population import Population
from Individual import Individual
import random
import numpy as np
import copy

class SearchAlgorithms:

    def SelfOrganizingMigration(self, dimension, interval, func, figName, interval_anim):
        pop_size = 30       # Velikost populace
        PRT = 0.4           # Pravděpodobnost pro směr pohybu
        PathLength = 3.0    # Počet skoků na trase k leadrovi
        Step = 0.11         # Vzdálenost skoku
        M_max = 100         # Počet migrací

        # Vytvoření populace jedinců
        population = Population(interval, dimension)
        population.GenerateIndividuals(pop_size)
        # Vypočítaní hodnot na funkci pro všechny jedince
        population.CalculateIndividuals(func)
        # Nalezení nejlepšího jedince (leadra)
        individual_best = copy.deepcopy(population.GetBestIndividual())

        m = 0
        t = Step

        # Pole historie populací pro vykreslení do animace
        population_history = []
        population_history.append(copy.deepcopy(population))

        # Průchod migrací
        while m < M_max:
            # Průchod jedinců v populaci
            for individual in population.individuals:
                # Pokud je aktuálně vybraný jedinec leader, provede se skip (leader se nepřesouvá)
                if individual.index == individual_best.index:
                    continue
                
                # Průchod trasy k leadrovi "individual_best"
                while t <= PathLength:
                    # Vytvoření hodnoty PRTVector pro výpočet nové pozice
                    PRTVector = 1 if random.uniform(0, 1) < PRT else 0
                    # Výpočet aktuálně nalezené pozice
                    current_position = individual.CalculateNewPosition(t, PRTVector, individual_best, interval)
                    current_position_f = individual.CalculateNewPositionF(func, current_position)

                    # Kontrola aktuálně nalezené pozice s zatím nejlepší nalezenou novou pozicí
                    if current_position_f <= individual.new_position_f:
                        individual.new_position_f = current_position_f
                        individual.new_position = current_position

                    t += Step
                # Uloží se nejlepší nová pozice jako aktuální pozice
                individual.SavePosition()
                t = Step
            # Nalezení nového nejlepšího jedince (leadra)
            individual_best = copy.deepcopy(population.GetBestIndividual())
            m += 1
            # Přidání populace do historie pro vykreslení
            population_history.append(copy.deepcopy(population))
        
        # Výpise nejlepší nalezené hodnoty a pozice
        print("The best found value at", figName, "function is", round(individual_best.f, 4), "at [", round(individual_best.coordinates[0], 4), "|", round(individual_best.coordinates[1], 4), "]")

        # Sestavení grafu
        graph = Graph(func, interval)
        graph.ShowByPopulation(figName, individual_best, population_history, interval_anim)

