import copy

class Individual:

    def __init__(self, coordinates, index):
        self.coordinates = coordinates
        self.f = None
        self.new_position = [0] * len(self.coordinates)
        self.new_position_f = None
        self.index = index  # označuje jedinečnost jedince

    # Provede výpočet na konkrétni funkci
    def CalculateF(self, func):
        self.f = func(self.coordinates)

    # Výpočet nové pozice jedince, samotná funkce kontroluje hranice na základě získaného rozsahu interval
    def CalculateNewPosition(self, t, PRTVector, individual_best, interval):
        position = []
        length = len(self.new_position)
        for i in range(length):
            position.append(self.coordinates[i] + (individual_best.coordinates[i] - self.coordinates[i]) * t * PRTVector)
            if position[i] < interval.lowerBound:
                position[i] = interval.lowerBound
            elif position[i] > interval.upperBound:
                position[i] = interval.upperBound

        return position

    # Provede výpočet nové pozice na konkrétní funkci
    def CalculateNewPositionF(self, func, position):
        return func(position)

    # Uloží novou nalezenou pozici jako aktuální
    def SavePosition(self):
        if self.new_position_f <= self.f:
            self.coordinates = copy.deepcopy(self.new_position)
            self.f = self.new_position_f

    # Vygeneruje novou pozici, která je v aktuálním místě (ještě nedošlo k požadavku o pohyb)
    def GenerateNewPosition(self):
        self.new_position = copy.deepcopy(self.coordinates)
        self.new_position_f = self.f