import matplotlib as matplb
import matplotlib.pyplot as plt
import numpy as np

class Graph:

    # Konstruktor třídy Graph nastavuje základní hodnoty proměnných pro konstrukci vizualizace grafu
    def __init__(self, func, interval):
        self.fig = plt.figure()
        self.ax = self.fig.add_subplot(111, projection='3d')
        self.func = func
        self.interval = interval

    # Zobrazení grafu
    def Show(self, figName, points = None, points_history = None, interval_anim = 1):
        # Sestavení bodů pro x a y skrze interval s následným vytvořením meshgridu
        x = y = np.arange(self.interval.lowerBound, self.interval.upperBound, self.interval.step)
        x, y = np.meshgrid(x, y)
        # Vytvoření křivky grafu dané funkce
        z = np.array([self.func([x, y]) for x, y in zip(np.ravel(x), np.ravel(y))])
        z = z.reshape(x.shape)

        # Sestavení grafu pomocí souřadnic
        self.ax.plot_surface(x, y, z, rstride=1, cstride=1, cmap=plt.get_cmap('jet'), alpha=0.3)

        # Pojmenování grafu a jednotlivých os
        self.ax.set_title(figName)
        self.ax.set_xlabel('X')
        self.ax.set_ylabel('Y')
        self.ax.set_zlabel('Z')

        # Cesta bodů v animaci
        self.path = None
        # Body, které se budou animovat (historie průchodu)
        self.points_to_anim = points_history

        # Vykreslení animace
        # => vykreslená historie průchodu je zobrazena červeně
        if self.points_to_anim != None:
            anim = matplb.animation.FuncAnimation(self.fig, self.anim, len(self.points_to_anim), interval=interval_anim, blit=False, repeat=False)

        # Vykreslení bodů získaných z vyhledávacího algoritmu
        # => výsledné body jsou vykresleny zeleně
        if points != None:
            for point in points:
                self.ax.scatter3D(point.x, point.y, point.z, c = '#00ff00')

        plt.show()

    # Vykreslení animace
    def anim(self, n):
        # Pokud je již vykreslený přechozí bod, tak ho odstraň
        if self.path != None:
            self.path.remove()

        # Pokud existuje bod pro vykreslení, tak ho vykresli
        if self.points_to_anim != None:
            self.path = self.ax.scatter3D(self.points_to_anim[n].x, self.points_to_anim[n].y, self.points_to_anim[n].z, c = '#ff0000')