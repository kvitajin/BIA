from Point import Point
from Graph import Graph
import random
import numpy as np

class SearchAlgorithms:

    # Generuje náhodné hodnoty pro vyhledávání skrze hodnoty z intervalu a dimenze
    def GenerateArray(self, lowerBound, upperBound, dimension):
        array = []

        for _ in range(dimension):  
            array.append(random.uniform(lowerBound, upperBound))
            
        return array

    # Provede kontrolu nového bodu a jeho pohybu na konkrétním intervalu
    def CalculatePoint(self, coordinates, coordinates_of_movement, interval):
        coordinates_of_movement[0] = coordinates[0] if coordinates_of_movement[0] + coordinates[0] <= interval.lowerBound or coordinates_of_movement[0] + coordinates[0] >= interval.upperBound else coordinates_of_movement[0] + coordinates[0]
        coordinates_of_movement[1] = coordinates[1] if coordinates_of_movement[1] + coordinates[1] <= interval.lowerBound or coordinates_of_movement[1] + coordinates[1] >= interval.upperBound else coordinates_of_movement[1] + coordinates[1]
        
        return coordinates_of_movement

    # Slepý vyhledávací algoritmus
    # Argumenty:
    #   cycles => počet vyhledávacích cyklů (počet bodů pro vyhledávání)
    #   dimension => dimenze, ve které se vyhledává
    #   interval => interval funkce
    #   func => funkce
    #   figName => název grafu
    def BlindSearch(self, cycles, dimension, interval, func, figName, interval_anim = 1):
        best_result = 8000  # Náhodná hodnota s nejlepším výsledkem
        best_choice = [800,800] # Náhodně zvolená nejlepší hodnota
        points = []
        points_history = []
        i = 0
        while i < cycles:
            # Vytvoření pole s náhodnou hodnotou pro danou dimenzi
            random_choice = self.GenerateArray(interval.lowerBound, interval.upperBound, dimension)
            current_result = func(random_choice)

            # Vytvoření bodu a přidání mezi zbytek bodů
            point = Point(random_choice[0], random_choice[1], current_result)
            points_history.append(point)

            # Pokud je aktuální výsledek menší (lepší => hledáme minimum) než nejlepší výsledek, pak dojde k přepisu proměnných
            if current_result < best_result:
                best_result = current_result
                best_choice = random_choice
            i += 1

        # Přidání nejlepšího výsledku do vykreslení
        point = Point(best_choice[0], best_choice[1], best_result)
        points.append(point)

        # Sestavení grafu
        graph = Graph(func, interval)
        graph.Show(figName, points, points_history)
        
        return best_result, best_choice

    def HillClimbing(self, cycles, dimension, interval, func, figName, interval_anim = 1):
        # Výběr prvního náhodného bodu
        random_choice = self.GenerateArray(interval.lowerBound, interval.upperBound, dimension)
        best_choice = func(random_choice)
        # Výsledný bod / body
        points = []
        # Historie postupu bodů
        points_history = []
        i = 1
        # Počet bodů pro rozhození v jednom cyklu
        test_range = 10
        # Rozsah bodů, ve kterém se mohou pohybovat v daném cyklu
        test_interval = [-interval.step, interval.step]
        temporary_result = random_choice
        while i <= cycles:
            for _ in range(test_range):
                # Vygenerování bodu (mutace) v okolí test_invervalu
                random_mutation = self.GenerateArray(test_interval[0], test_interval[1], dimension)
                # Přiřazení bodu do funkce
                random_mutation = self.CalculatePoint(random_choice, random_mutation, interval)
                mutation_result = func(random_mutation)

                # Kontrola, jestli je zmutovaný bod lepší, než aktuální nejlepší hodnota
                if mutation_result <= best_choice:
                    temporary_result = random_mutation
                    best_choice = mutation_result

            # Uložení aktuálního nejlepšího výsledku v daném cyklu
            random_choice = temporary_result
            i += 1
            # Přiřazení aktuálně nejlepšího výsledku do historie
            point = Point(random_choice[0], random_choice[1], best_choice)
            points_history.append(point)

        # Přiřazení nejlepšího nalezeného bodu do výsledku pro vykreslení
        point = Point(random_choice[0], random_choice[1], best_choice)
        points.append(point)

        # Sestavení grafu
        graph = Graph(func, interval)
        graph.Show(figName, points, points_history, interval_anim)

        return best_choice, random_choice

    def SimulatedAnnealing(self, cycles, dimension, interval, func, figName, interval_anim = 1):
        # Aktuální teplota
        T_0 = 100
        # Minimální teplota
        T_min = 0.5
        # Tempo chlazení
        alpha = 0.95

        T = T_0

        # Vygenerování prvního náhodného bodu
        x_a = self.GenerateArray(interval.lowerBound, interval.upperBound, dimension)
        x = func(x_a)
        
        # Interval testování v okolí okolo bodu
        test_interval = [-interval.step, interval.step]

        # Body pro vykreslení
        points_history = []
        points = []

        # Náhodné hodnoty výsledku
        best_result = 8000
        best_result_coordinates = [800,800]

        while T > T_min:
            for _ in range(cycles):
                # Vygenerování bodu (mutace) v okolí test_invervalu
                x_1_a = self.GenerateArray(test_interval[0], test_interval[1], dimension)
                
                # Přiřazení bodu do funkce
                x_1_a = self.CalculatePoint(x_a, x_1_a, interval)
                x_1 = func(x_1_a)

                # Kontrola nalezeného bodu, pokud je menší než aktuální výsledek, tak se přepíše (hledá se minimum)
                if x_1 < x:
                    x = x_1
                    x_a = x_1_a
                    point = Point(x_a[0], x_a[1], x)
                    points_history.append(point)

                    # Pokud je aktuální bod lepší, než celkově nejlepší nalezený bod, tak se přepíše jako hlavní výsledek
                    if x < best_result:
                        best_result = x
                        best_result_coordinates = x_1_a
                # Prohledávání okolí
                else:
                    r = random.uniform(0, 1)

                    if r < np.e**(-(x_1 - x) / T):
                        x = x_1
                        x_a = x_1_a
                        point = Point(x_a[0], x_a[1], x)
                        points_history.append(point)
            # Snížení teploty
            T = T * alpha

        # Přiřazení nejlepšího nalezeného bodu do výsledku pro vykreslení
        point = Point(best_result_coordinates[0], best_result_coordinates[1], best_result)
        points.append(point)

        # Sestavení grafu
        graph = Graph(func, interval)
        graph.Show(figName, points, points_history, interval_anim)

        return best_result, best_result_coordinates