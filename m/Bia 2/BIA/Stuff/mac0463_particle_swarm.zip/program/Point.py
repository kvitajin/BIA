# Bod, který slouží pro výpočty a vykreslení v grafu
class Point:

    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z