import random
import numpy as np
from Individual import Individual
from operator import attrgetter

class Population:

    # Privátní promměná, která nabývá hodnoty true, pokud již jedinci byli ohodnoceni (kvůli výběru nejlepšího jedince)
    __individualsWereCalculated = False
    # Privátní hodnota indexu pro následujícího jedince
    __lastCreatedIndex = 0

    def __init__(self, cities):
        self.individuals = []
        self.cities = cities

    # Navýšení indexu pro nového jedince
    def __IncrementLastCreatedIndex(self):
        self.__lastCreatedIndex += 1

    # Generuje jedinečného jedince se startovacím městem
    def GenerateIndividual(self, city):
        individual = Individual(city, len(self.cities.Return()), self.__lastCreatedIndex)
        self.__IncrementLastCreatedIndex()
        
        return individual

    # Vytvoření populace jedinců
    def GenerateIndividuals(self, number):
        if self.individuals:
            return

        for i in range(number):
            self.individuals.append(self.GenerateIndividual(self.cities.Return()[i]))

    # Přidání nového města pro všechny jedince
    def CalculateIndividuals(self):
        self.__individualsWereCalculated = True
        
        for i in range(len(self.individuals)):
            self.CalculateIndividual(i)

    # Přidání nového města na základu výpočtu pravděpodobnosti
    def CalculateIndividual(self, individual_id):
        alpha = 1
        beta = 2

        probabilities = {}      # Pravděpodobnosti pro jednotlivě vybrané města
        probability_sum = 0     # Suma součtu vzdáleností mezi vybraným městem a ostatními

        # Průchod všech měst
        for i in range(len(self.cities.Return())):
            # Pokud vybrané město se již nachází v cestě u jedince (jedinec už město navštívil), tak pokračuj k dalšímu
            if any(x.name == self.cities.Return()[i].name for x in self.individuals[individual_id].path):
                continue
            # Posledně navštívené město
            last_visited_city = self.individuals[individual_id].path[len(self.individuals[individual_id].path) - 1]
            # Výpočet horní části - pheromon[poslední navštívené město][aktuálně vybrané nenavštívené město]^aplha * visibility_matrix[poslední navštívené město][aktuálně vybrané nenavštívené město]^beta
            probability = self.cities.pheromones[last_visited_city.index][i]**alpha * self.cities.visibility_matrix[last_visited_city.index][i]**beta
            # Přidání pravděpodobnosti pro konkrétní město (cestu k danému městu)
            probabilities[i] = probability
            # Přičtení hodnoty do sumy
            probability_sum += probability

        # Pokud suma nabývá hodnoty 0, pak je jasné, že se nacházíme u průchodu poslední město - první město, kde nemusíme hodnotu počítat,
        # respektive trasa je již kompletní a je zbytečné přidávat opět první město, které je už na první pozici
        if probability_sum == 0:
            return

        # Výběr náhodné hodnoty pro výběr nového města do cesty
        r = random.uniform(0, 1)
        probability_percentage = 0
        result = None

        # Průchod hodnot pravděpodobností u jednotlivých tras
        for key in probabilities:
            # Přepočet pravděpodobnosti na základě sumy
            probabilities[key] = probabilities[key] / probability_sum
            # Přičtení k procentuální šanci
            probability_percentage += probabilities[key]
            # Výběr následující města na základě procentuální pravděpodobnosti
            # Pokud bylo město vybráno, tak není smysl pokračovat v cyklu dál
            if r <= probability_percentage:
                result = self.cities.Return()[key]
                break
        
        # Přidání nového města do cesty
        self.individuals[individual_id].path.append(result)

    # Přepočítání feromonů na základě průchodů cest všech mravenců
    def RecalculatePheromones(self):
        Q = 1
        # Matice pro součet jedtnolivých vzdáleností pro konkrétní města
        recalculation_matrix = np.zeros((len(self.cities.pheromones), len(self.cities.pheromones)))
        for individual in self.individuals:
            # Výpočet celkové vzdálenosti pro konkrétního jedince
            evaluation = individual.EvaluateDistance(self.cities.CalculateDistance)
            individual_length = len(individual.path)
            # Přičtení hodnoty Q/f(s) pro všechny pozice, které konkrétní jedince navštívil
            for i in range(individual_length):
                # Pokud se nacházíme na hodnotě posledního města, tak provedeme výpočet s posledním a prvním
                if i + 1 == individual_length:
                    recalculation_matrix[individual.path[individual_length - 1].index][individual.path[0].index] += Q / evaluation
                    break

                recalculation_matrix[individual.path[i].index][individual.path[i + 1].index] += Q / evaluation

        p = 0.5
        # Výsledný přepočet vaporizace feromonů
        for i in range(len(self.cities.pheromones)):
            for j in range(len(self.cities.pheromones[i])):
                self.cities.pheromones[i][j] = (1 - p) * self.cities.pheromones[i][j] + recalculation_matrix[i][j]

    # Vyresetuje pozice všech jedinců
    def ResetIndividuals(self):
        for i in range(len(self.individuals)):
            self.individuals[i].ResetPath()
        
    # Funkce vrací nejlepšího jedince, pokud nebyli ještě jedinci ohodnoceni, vrátí se hodnota None
    def GetBestIndividual(self):
        if not self.__individualsWereCalculated:
            return None
        return min(self.individuals, key = attrgetter("currentDistance"))
