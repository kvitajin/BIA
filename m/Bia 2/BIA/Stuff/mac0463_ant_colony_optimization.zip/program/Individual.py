import copy

class Individual:

    def __init__(self, starting_city, max_cities, index):
        self.path = [starting_city]             # Cesta průchodu
        self.starting_city = starting_city      # Startovní město
        self.max_cities = max_cities            # Maximální počet měst
        self.currentDistance = 0                # Aktuální vzdálenost cesty
        self.index = index                      # Označuje jedinečnost jedince

    # Přidání města do cesty
    def AddCityToPath(self, city):
        if len(self.path) < self.max_cities:
            self.path.append(city)

    # Resetování cesty
    def ResetPath(self):
        self.path.clear()
        self.path.append(self.starting_city)

    # Výpočet vzdálenosti mezi jednotlivými městy
    def EvaluateDistance(self, func_CalculateDistance):
        path_length = len(self.path)
        evaluation = 0

        # Průchod celé cesty mezi všemi městy
        for i in range(path_length):
            # Pokud se jedná o poslední město, vypočti poslední vzdálenost mezi posledním městem a prvním a přičti k celku
            if i == path_length - 1:
                evaluation += func_CalculateDistance(self.path[i], self.path[0])
                continue
            # Vypočti vzdálenost mezi aktuálním a následujícím městem a přičti k celku
            evaluation += func_CalculateDistance(self.path[i], self.path[i + 1])
        
        # Uložení hodnoty do aktuální vzdálenosti (slouží pak pro výběr nejlepšího jedince)
        self.currentDistance = evaluation
        return evaluation