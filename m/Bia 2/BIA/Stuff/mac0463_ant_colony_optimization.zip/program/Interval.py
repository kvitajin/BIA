# Interval pro funkce
class Interval:

    def __init__(self, lowerBound, upperBound, step = 1):
        self.lowerBound = lowerBound
        self.upperBound = upperBound
        self.step = step