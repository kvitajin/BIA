from Cities import Cities
from Population import Population
from Graph import Graph
import random
import numpy as np
import string
import copy

class SearchAlgorithms:

    # Samotný genetický algoritmus
    def AntColony(self, interval):
        M = 60 # Počet průběhů
        N = 20  # Počet měst a jedinců
        # Vygenerování měst
        cities = Cities(interval)
        cities.Generate(N)
        # Vygenerování populace
        population = Population(cities)
        population.GenerateIndividuals(N)

        # Historie pro vykreslení v animaci
        points_history = []

        best_result = None

        # Průchod cyklů průběhu, kdy mravenci hledají nejlepší cestu
        for i in range(M):
            # Průchod počtu měst, kde každým jedním průchodem je přidáno jedno nové město pro každého jedince
            for j in range(N):
                # Každý mravenec si na základě pravděpodobnosti skrze feromony přidá jedno následující město
                population.CalculateIndividuals()
            # Po skončení cyklu již každý mravenec zná celou svou cestu
            # Proto je nezbytné na základě jejich cest provést přepočet feromonů
            population.RecalculatePheromones()
            
            # Provede se výber nejelpšího jedince na základě délky jeho cesty
            result = copy.deepcopy(population.GetBestIndividual())
            # Pokud ještě nemáme žádný výsledek, pak se nastavý jako nejlepší
            if best_result is None:
                best_result = result
            # Pokud již výsledek máme, tak ho porovnáme s aktuálním, pokud je aktuální lepší (menší), pak se provede přepis
            elif result.currentDistance < best_result.currentDistance:
                best_result = result
            # Nejlepší nalezený výsledek se uloží do historie průchodů
            points_history.append([best_result])
            # Nakonec se provede reset cesty všem jedincům pro vytvoření nového průchodu na základě feromonů
            population.ResetIndividuals()

        # Zobrazení grafu
        graph = Graph(interval)
        graph.Show("Ant Colony Optimization", cities.Return(), points_history)
