# Bod, který slouží pro výpočty a vykreslení v grafu
class Point:

    def __init__(self, x, y, name, index):
        self.x = x
        self.y = y
        self.name = name
        self.index = index